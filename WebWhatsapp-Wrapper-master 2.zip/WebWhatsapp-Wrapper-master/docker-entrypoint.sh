#!/usr/bin/env bash

pip install ./
pip list
python sample/remote.py
