"""
/**********************************************************

		File name	: wsgi.py
		Description	: Contains entry point to app
                      called from WebAPI.ini
                      The file include the app from main py
                      file WebAPI.py

DATE		PROGRAMMER		COMMENT
18/09/18	rbnishant		Initial Version

**********************************************************/
"""

from webapi import app
